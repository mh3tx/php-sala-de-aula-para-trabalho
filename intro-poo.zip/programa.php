<?php

include "Pessoa.class.php";
include "Aluno.class.php";
include "Funcionario.class.php";
include "Instrutor.class.php";
include "WebDesign.class.php";

/*
$aluno1 = new Aluno("Pedro", "A123"); //criando uma instancia de aluno.
$aluno1->assisteAula();
*/

$func1 = new Instrutor("Jose", "F789");
$func1->recebeSalario();

$func2 = new WebDesign("Maria", "F889");
$func2->recebeSalario();




