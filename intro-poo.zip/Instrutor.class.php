<?php
class Instrutor extends Funcionario
{
	public function __construct($nome, $matricula)
	{
		$this->nome = $nome;
		$this->matricula = $matricula;
	}
	
	public function recebeSalario()
	{
		$salario = $this->recebePercentualCurso("a", 5000) + 750;
		echo "Instrutor {$this->nome} recebe salario: $salario  ";
	}
	
	private function recebePercentualCurso($origem, $valor)
	{
		if ($origem == "a") return $valor / 2;
		if ($origem == "b") return $valor / 3;
	}
	
}