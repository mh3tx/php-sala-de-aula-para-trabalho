<?php
class Aluno extends Pessoa
{
	public function __construct($nome, $matricula)
	{
		$this->nome = $nome;
		$this->matricula = $matricula;
	}
	
	public function assisteAula()
	{
		echo "aluno {$this->nome} assistindo aula.  ";
	}
	
} //fim da classe Aluno