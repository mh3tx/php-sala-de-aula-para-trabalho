<?php
class WebDesign extends Funcionario
{
	public function __construct($nome, $matricula)
	{
		$this->nome = $nome;
		$this->matricula = $matricula;
	}
	
	public function recebeSalario()
	{
		$salario = 4000;
		echo "Web Design {$this->nome} recebe salario: $salario  ";
	}
}