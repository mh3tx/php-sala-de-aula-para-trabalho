<?php
abstract class Funcionario extends Pessoa
{
	abstract protected function recebeSalario();
	
} //fim da classe Funcionario