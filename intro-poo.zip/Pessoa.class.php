<?php
abstract class Pessoa
{
	protected $matricula;
	protected $nome;
}