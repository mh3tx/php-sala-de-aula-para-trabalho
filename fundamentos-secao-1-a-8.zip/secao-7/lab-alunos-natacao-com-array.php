<?php
/*
Construa um programa que receba a idade de um aluno e matricule-o em uma turma de natação de acordo com a faixa etária:
6 a 9 - kids
10 a 14 - infantil
15 a 17 - juvenil
18 a 44 adulto
acima de 44 senior

No final, imprima na tela: nome, idade e a categoria em que o aluno foi matriculado. 
*/

$aTurma = [
	'A135' => 
		[
			'nome' => 'Maria',
			'idade' => 7,
			'uf' => 'SP'	
		],
		
	'A448' => 
		[
			'nome' => 'João',
			'idade' => 12,
			'uf' => 'DF'	
		],
	'A774' => 
		[
			'nome' => 'Pedro',
			'idade' => 22,
			'uf' => 'CE'	
		]
];		

$categoria = "";
$invalida = "Idade inválida para matrícula: " . PHP_EOL;

foreach($aTurma as $aluno) {
	if ($aluno['idade'] < 6) {
		$invalida .= "Nome: {$aluno['nome']} Idade: {$aluno['idade']} " . PHP_EOL;
		continue;
	}

	if ($aluno['idade'] >= 6 and $aluno['idade'] <= 9) $categoria = "Kids";
	if ($aluno['idade'] >= 10 and $aluno['idade'] <= 14) $categoria = "Infantil";
	if ($aluno['idade'] >= 15 and $aluno['idade'] <= 17) $categoria = "Juvenil";
	if ($aluno['idade'] >= 18 and $aluno['idade'] <= 44) $categoria = "Adulto";
	if ($aluno['idade'] >= 45) $categoria = "Senior";

	echo "Nome: {$aluno['nome']} Idade: {$aluno['idade']} Categoria $categoria" . PHP_EOL;
} //fim do loop

echo PHP_EOL;
echo $invalida;











