<?php 
/*
Arrays no PHP...
usando loops com valores fixos na variavel de controle... Isso pode dar problema quando o array muda de tamanho.
*/
$idades = [7,12,22,40,55];

/*
echo $idades[0] . PHP_EOL;
echo $idades[1] . PHP_EOL;
echo $idades[2] . PHP_EOL;
echo $idades[3] . PHP_EOL;
echo $idades[4] . PHP_EOL;
*/

/*
for ($i = 0; $i < 5; $i++) {
	echo $idades[$i] . PHP_EOL;
}
*/

/*
$i = 0;


while ($i < 5) {
	echo $idades[$i] . PHP_EOL;
	$i++;
}

do {
	echo $idades[$i] . PHP_EOL;
	$i++;
} while ($i < 5);
*/