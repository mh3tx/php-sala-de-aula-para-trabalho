<?php 
/*
Arrays associativos com dados diferentes...
*/
$aTurma = [
	'A135' => 
		[
			'nome' => 'Maria',
			'idade' => 7,
			'uf' => 'SP'	
		],
		
	'A448' => 
		[
			'nome' => 'João',
			'idade' => 12,
			'uf' => 'DF'	
		],
	'A774' => 
		[
			'nome' => 'Pedro',
			'idade' => 22,
			'uf' => 'CE'	
		]
];

foreach($aTurma as $chaveDaVez => $oAlunoDaVez) {
	echo "Código: $chaveDaVez" . PHP_EOL;
	echo "Nome: {$oAlunoDaVez['nome']}" . PHP_EOL;
	echo "Idade: {$oAlunoDaVez['idade']}" . PHP_EOL;
	echo "UF: {$oAlunoDaVez['uf']}" . PHP_EOL;
	echo "-----------------" . PHP_EOL;
}

//brincando de adicionar um aluno à turma...
$aTurma['A333'] = 
		[
			'nome' => 'Ana',
			'idade' => 35,
			'uf' => 'SC'	
		];

//brincando de removar um aluno da turma.		
unset($aTurma['A333']);		

echo PHP_EOL;echo PHP_EOL;echo PHP_EOL;

foreach($aTurma as $chaveDaVez => $oAlunoDaVez) {
	echo "Código: $chaveDaVez" . PHP_EOL;
	echo "Nome: {$oAlunoDaVez['nome']}" . PHP_EOL;
	echo "Idade: {$oAlunoDaVez['idade']}" . PHP_EOL;
	echo "UF: {$oAlunoDaVez['uf']}" . PHP_EOL;
	echo "-----------------" . PHP_EOL;
}

