<?php 
/*
Arrays no PHP...
Associativos
*/
$idades = [
	15 => 7,
	7 => 12,
	33 => 22,
	77 => 40,
	100 => 55
];


foreach($idades as $idadeDaVez) {
	echo $idadeDaVez . PHP_EOL;
}

foreach($idades as $chave => $idadeDaVez) {
	echo "[$chave] => $idadeDaVez" . PHP_EOL;
}


/*
Com arrays associativos (com índices arbitrários) esta mecânica não vai funcionar pois ela espera que o loop seja
iterado pelo índice iniciando de 0 até N

for ($i = 0; $i < count($idades); $i++) {
	echo $idades[$i] . PHP_EOL;
}
*/

