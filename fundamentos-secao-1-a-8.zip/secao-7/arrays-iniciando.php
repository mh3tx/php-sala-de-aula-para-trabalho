<?php 
/*
Arrays no PHP...
*/
$idades = [7,12,22];

var_dump($idades);
