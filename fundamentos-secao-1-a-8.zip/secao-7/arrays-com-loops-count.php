<?php 
/*
Arrays no PHP...
usando loops com valores fixos na variavel de controle... Isso pode dar problema quando o array muda de tamanho.
*/
$idades = [7,12,22,40,55];

/*
for ($i = 0; $i < count($idades); $i++) {
	echo $idades[$i] . PHP_EOL;
}
*/

/*
$i = 0;


while ($i < count($idades)) {
	echo $idades[$i] . PHP_EOL;
	$i++;
}

do {
	echo $idades[$i] . PHP_EOL;
	$i++;
} while ($i < count($idades));
*/