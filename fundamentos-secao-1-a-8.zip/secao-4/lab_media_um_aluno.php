<?php
/*
Laboratório: crie um programa que simule o recebimento do nome, da idade e 3 notas de aluno. Calcule sua média e informe como saida: O nome, a idade, as 3 notas, a média do aluno; e, se o aluno foi aprovado ou reprovado. 
*/
//Entrada de dados...
define("VALOR_MEDIA", 6.0); //constante
define("QTD_NOTAS", 3); //constante

$nome = "Maria da Silva";
$idade = 21;
$n1 = 7.8; $n2 = 6.9; $n3 = 9.2;

//Processamento de dados...
$media = ($n1+$n2+$n3)/QTD_NOTAS;
$situacao = ($media >= VALOR_MEDIA)?'APROVADO':'REPROVADO'; //if ternário

//Saida de dados...
$saida = "Aluno(a): $nome Idade: $idade" . PHP_EOL;
$saida .= "Nota 1: $n1" . PHP_EOL . "Nota 2:$n2" . PHP_EOL . "Nota 3: $n3" . PHP_EOL;
$saida .= "Média: " . number_format($media,2) . PHP_EOL . "Situação: $situacao";
echo $saida;





?>