<?php

/*
Tomando decisões com switch case
- Quando temos controle sobre o que estamos comparando.
*/
$nome = 'João';
$idade = 13;
$pais = 'US';

switch ($pais) {
	case 'BR':
		if ($idade >= 18) {
			echo "Olá $nome vc tem $idade anos, mora no $pais e pode tirar sua habilitação. " . PHP_EOL;
		} 
		else {
			echo "Olá $nome vc tem $idade anos, mora no $pais e ainda não pode tirar habilitação.";
		}
	
		break;

	case 'US':
		if ($idade >= 16) {
			echo "Olá $nome vc tem $idade anos, mora no $pais e pode tirar sua habilitação. " . PHP_EOL;
		} 
		else {
			echo "Olá $nome vc tem $idade anos, mora no $pais e ainda não pode tirar habilitação.";
		}
	
		break;
}



?>