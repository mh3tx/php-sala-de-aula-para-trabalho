<?php

/*
Tomando decisões com if else
- if (se)
- if/else (se/senão...)
- if else aninhados (um dentro do outro)
- A importância da identação.
*/

//entrada de dados...
$nome = 'João';
$idade = 17;
$pais = 'BR';

//processamento dos dados...
if ($pais == 'BR') {
	if ($idade >= 18) {
		echo "Olá $nome vc tem $idade anos, mora no $pais e pode tirar sua habilitação. " . PHP_EOL;
	} 
	else {
		echo "Olá $nome vc tem $idade anos, mora no $pais e ainda não pode tirar habilitação.";
	}
}
else {
	if ($pais == 'US') {
		if ($idade >= 16) {
			echo "Olá $nome vc tem $idade anos, mora no $pais e pode tirar sua habilitação. " . PHP_EOL;
		} 
		else {
			echo "Olá $nome vc tem $idade anos, mora no $pais e ainda não pode tirar habilitação.";
		}
	}	
}
?>



