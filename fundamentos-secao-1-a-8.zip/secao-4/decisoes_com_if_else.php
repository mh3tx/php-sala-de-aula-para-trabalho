<?php

/*
Tomando decisões com if else
- if (se)
- if/else (se/senão...)
- if else aninhados (um dentro do outro)
- A importância da identação.
*/

//entrada de dados...
$nome = 'João';
$idade = 17;

//processamento dos dados...
if ($idade >= 18) {
	echo "Olá $nome vc pode tirar sua habilitação. " . PHP_EOL;
} 
else {
	echo "Olá $nome vc ainda não pode tirar habilitação.";
}


?>