<?php

/*
Tomando decisões com switch case
- Quando temos controle sobre o que estamos comparando.
*/
$corPref = 'Azul3';

switch ($corPref) {
	case 'Verde':
		echo "sua cor preferida é VERDE";
		break;
	case 'Azul':
		echo "sua cor preferida é AZUL";
		break;
	case 'Amarelo':
		echo "sua cor preferida é AMARELO";
		break;
	case 'Rosa':
		echo "sua cor preferida é ROSA";
		break;
	case 'Vermelho':
		echo "sua cor preferida é VERMELHO";
		break;
	default:
		echo "Cor não reconhecida.";
}



?>