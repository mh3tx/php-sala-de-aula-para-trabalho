<?php

/*
Tomando decisões com if ternário. O que é isso?
*/

//entrada de dados...
$nome = 'João';
$idade = 18;

//processamento dos dados...

$mensagem = ($idade >= 18)?"Olá $nome vc pode tirar habilitação.":"Olá $nome vc ainda não pode tirar habilitação.";

echo $mensagem;

?>
