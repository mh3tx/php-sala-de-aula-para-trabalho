<?php

/*
Loops (estruturas de controle) laços de repetição...

while, do while, for...
*/

for ($contador = 1; $contador < 6; $contador++) {
	echo "#$contador" . PHP_EOL;
}

/*

$contador = 1; //inicializa a variavel de controle do loop.

while ($contador < 6) {
	echo "#$contador" . PHP_EOL;
	$contador++; //controle da variável contador.
}


do {
	echo "#$contador" . PHP_EOL;
	$contador++; //controle da variável contador.
} while ($contador < 6);
*/

?>