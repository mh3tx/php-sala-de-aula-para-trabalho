<?php

/*
Loops (estruturas de controle) laços de repetição...

while, do while, for...
*/

for ($i = 1; $i < 4; $i++) {
	echo "Loop externo #$i" . PHP_EOL . PHP_EOL;
	
	for ($j = 10; $j < 14; $j++) {
		echo "Loop interno j: #$j" . PHP_EOL . PHP_EOL;
	}	
	
	echo PHP_EOL;
}

?>