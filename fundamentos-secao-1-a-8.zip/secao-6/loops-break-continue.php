<?php

/*
Loops (estruturas de controle) laços de repetição...

while, do while, for...
break e continue...
*/

for ($i = 1; $i <= 10; $i++) { //loop pretende dar 10 voltas...
	if ($i == 7) {
		continue; //aborta a volta atual e itera para a próxima volta do loop.
	}
	echo "Volta #$i" . PHP_EOL;
}

echo "Fim do loop.";

?>