<?php
/*
Laboratório: construa um programa que faça a varredura de uma faixa de valores de 1 a 100 e marque os números pares.
*/

for ($i = 1; $i <= 100; $i++) {
	$par = "";
	if ($i % 2 == 0) {
		$par = "PAR";
	}
	
	echo "$i $par" . PHP_EOL;
}
?>






