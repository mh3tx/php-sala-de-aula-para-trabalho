<?php

/*
Loops (estruturas de controle) laços de repetição...

while, do while, for...
*/

$i = 1; //contador...
for (;;) {
	if ($i < 6) {
		echo "#$contador" . PHP_EOL;
	}
	$i++; //controle da variavel contador.
}

/*

$contador = 1; //inicializa a variavel de controle do loop.

while ($contador < 6) {
	echo "#$contador" . PHP_EOL;
	$contador++; //controle da variável contador.
}


do {
	echo "#$contador" . PHP_EOL;
	$contador++; //controle da variável contador.
} while ($contador < 6);
*/

?>