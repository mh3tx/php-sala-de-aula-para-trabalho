<?php
/*
Laboratório: construa um programa que calcule as tabuadas dos números 1 até 10.
*/

//usando o for...
/*
for ($i = 1; $i <= 10; $i++) { //loop externo.
	echo "Tabuada do #$i" . PHP_EOL . PHP_EOL;
	
	for ($j = 0; $j <= 10; $j++) { //loop interno.
		$resultado = $i * $j; //calcula o resultado a cada volta...
		echo "$i X $j = $resultado" . PHP_EOL;
	}
		
	echo PHP_EOL;	
}
exit;
*/

/*
//usando while...
$i = 1;
while ($i <= 10) {
	echo "Tabuada do #$i" . PHP_EOL . PHP_EOL;

	$j = 0;
	while ($j <= 10) {
		$resultado = $i * $j; //calcula o resultado a cada volta...
		echo "$i X $j = $resultado" . PHP_EOL;
		$j++; //incrementa contador do loop interno...
	}
	
	$i++; //incrementa contador do loop externo...
	echo PHP_EOL;
}	
exit;
*/

//usando do-while
$i = 1;
do {
	echo "Tabuada do #$i" . PHP_EOL . PHP_EOL;

	$j = 0;
	while ($j <= 10) {
		$resultado = $i * $j; //calcula o resultado a cada volta...
		echo "$i X $j = $resultado" . PHP_EOL;
		$j++; //incrementa contador do loop interno...
	}
	
	$i++; //incrementa contador do loop externo...
	echo PHP_EOL;
} while ($i <= 10); //loop externo... 
exit;



?>






