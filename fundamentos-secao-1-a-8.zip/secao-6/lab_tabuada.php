<?php
/*
Laboratório: construa um programa que calcule a tabuada entre 0 e 10, de um número inteiro.
*/

$tabuada = 5;

//usando o for...
/*
for ($i = 0; $i <= 10; $i++) {
	$resultado = $tabuada * $i; //calcula o valor a cada volta...
	echo "$tabuada X $i = $resultado" . PHP_EOL;	
}
exit;
*/

//usando while...
/*
$i = 0;
while ($i <= 10) {
	$resultado = $tabuada * $i; //calcula o valor a cada volta...
	echo "$tabuada X $i = $resultado" . PHP_EOL;	
	$i++;
}
exit;
*/

//usando do while
$i = 0;
do {
	$resultado = $tabuada * $i; //calcula o valor a cada volta...
	echo "$tabuada X $i = $resultado" . PHP_EOL;	
	$i++;
} while ($i <= 10);
exit;
?>






