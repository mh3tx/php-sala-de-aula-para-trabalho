<?php
/*
- Diferença de usar aspas duplas e aspas simples na formatação de texto.
- Concatenação de texto com variáveis.
*/
$nome = 'Pedro da Silva';
$idade = 25;
$cidade = 'Brasília';
$comidaPref = 'Churrasco';

//echo 'Olá, seja bemvindo(a) ' . $nome . '\r\n você tem ' . $idade . ' anos e mora em ' . $cidade;

echo "Olá, seja bemvindo(a) $nome \r\nvocê tem $idade anos e mora em $cidade sua comida preferida é $comidaPref";

?>