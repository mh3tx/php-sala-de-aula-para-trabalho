<?php

/*
Operadores Lógicos...

Curto circuito: AND, &&, OR, ||

AND, &&: Se a primeira expressão avaliada for falsa, nem perde tempo avaliando a segunda expressão. O resultado é falso! Entretanto se a primeira expressão for verdadeira, ele executa a segunda expressão...

OR, ||: Se a primeira expressão for verdadeira, nem perde tempo avaliando a segunda expressão. O resultado é verdadeiro! Entretanto se a primeira expressão for falsa, ele avalia a segunda expressão...

Operador de negação: !
*/

if (false xor false) {
	echo "resultado verdadeiro";
}
else {
	echo "resultado falso";
}
?>
