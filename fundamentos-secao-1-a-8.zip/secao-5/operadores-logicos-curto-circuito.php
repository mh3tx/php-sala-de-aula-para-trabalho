<?php

/*
Operadores Lógicos...

Curto circuito: AND, &&, OR, ||

AND, &&: Se a primeira expressão avaliada for falsa, nem perde tempo avaliando a segunda expressão. O resultado é falso! Entretanto se a primeira expressão for verdadeira, ele executa a segunda expressão...

OR, ||: Se a primeira expressão for verdadeira, nem perde tempo avaliando a segunda expressão. O resultado é verdadeiro! Entretanto se a primeira expressão for falsa, ele avalia a segunda expressão...

Operador de negação: !
*/

$imprime_eu_tio = "fica_quieto_menino";

if (1==1 or $imprime_eu_tio="*@_@*") {
	echo "resultado verdadeiro";
}
else {
	echo "resultado falso";
}

echo PHP_EOL;
echo $imprime_eu_tio;
?>
