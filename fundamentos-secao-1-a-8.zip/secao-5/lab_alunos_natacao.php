<?php
/*
Construa um programa que receba a idade de um aluno e matricule-o em uma turma de natação de acordo com a faixa etária:
6 a 9 - kids
10 a 14 - infantil
15 a 17 - juvenil
18 a 44 adulto
acima de 44 senior

No final, imprima na tela a categoria em que o aluno foi matriculado. 
*/

$idade = 22;
$categoria = "";

if ($idade < 6) {
	echo "Idade inválida para ser matriculado.";
	exit;
}

if ($idade >= 6 and $idade <= 9) $categoria = "Kids";
if ($idade >= 10 and $idade <= 14) $categoria = "Infantil";
if ($idade >= 15 and $idade <= 17) $categoria = "Juvenil";
if ($idade >= 18 and $idade <= 44) $categoria = "Adulto";
if ($idade >= 45) $categoria = "Senior";

echo $categoria;
?>