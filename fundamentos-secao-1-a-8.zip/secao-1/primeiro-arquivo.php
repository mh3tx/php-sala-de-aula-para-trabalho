<?php 
echo "Este é o primeiro arquivo php" . PHP_EOL;
echo "Testando o PHP" . PHP_EOL;
echo "Estou gostando de estudar.";
