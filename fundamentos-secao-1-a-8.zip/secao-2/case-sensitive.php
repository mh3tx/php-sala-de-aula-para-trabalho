<?php
/*
- Variável é uma região na memória do computador usada para guardar valores temporários.
- Nomes de variáveis tem regras: deve/pode conter letras, números e underscore mas deve iniciar com $ seguido de
letras ou underscore. (Há uma exceção para nomes de variáveis).
- São case-sensitives, ou seja, diferem letras maiúsculas e minúsculas. Exemplo: $nome é diferente de $NOME.
*/

$nome = "Pedro da Silva"; 
echo $nome . PHP_EOL;
$Nome = "Maria da Silva";
echo $Nome;
?>