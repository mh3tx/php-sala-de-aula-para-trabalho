<?php
/*
- Variável é uma região na memória do computador usada para guardar valores temporários.
- Nomes de variáveis tem regras: deve/pode conter letras, números e underscore mas deve iniciar com $ seguido de
letras ou underscore. (Há uma exceção para nomes de variáveis).
- São case-sensitives, ou seja, diferem letras maiúsculas e minúsculas. Exemplo: $nome é diferente de $NOME.
- Variável variável: deve ser usado $$. O conteúdo de uma variável que já existe, forma o identificador de uma
nova variável.
*/

$var = 123;
echo $var;
$$var = "php"; //$123 = "php";
echo PHP_EOL;
echo ${123};

?>