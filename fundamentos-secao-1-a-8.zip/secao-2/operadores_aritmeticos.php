<?php 

/*
- Alguns operadores aritméticos, de atribuição e de comparação.
- Entendendo um pouco sobre precedência.
*/

$a = 5;
$b = 3;
$resultado = ($a % $b);

echo $resultado; //valor armazenado
echo PHP_EOL;
?>