<?php
$variavel = 777;
echo gettype($variavel) . PHP_EOL;
$variavel = "João da Silva";
echo gettype($variavel) . PHP_EOL;
$variavel = true;
echo gettype($variavel);




