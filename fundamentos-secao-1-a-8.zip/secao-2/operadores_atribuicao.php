<?php 

/*
- Alguns operadores aritméticos, de atribuição e de comparação.
- Entendendo um pouco sobre precedência.
*/

$a = 3;
$a += 5; //$a = $a + 5;
$a -= 5; //$a = $a - 5;
$a *= 5; //$a = $a * 5;
$a /= 5; //$a = $a / 5;
$a %= 5; //$a = $a % 5;
$a **= 5; //$a = $a ** 5;

$msg = "Hello";
$msg .= " World"; //$msg = $msg . " World"

echo $msg;

?>