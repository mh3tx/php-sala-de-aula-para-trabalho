<?php
/*
O básico sobre operadores de comparação...

a) entender o que estamos comparando:
7 == "7" em execução o PHP transforma a String em inteiro... Logo, Valores iguais mas Tipos diferentes...
false e true (booleanos); "false" e "true" apenas Strings...

b) Saber como o PHP entende a comparação:
- Strings que representam números válidos o PHP, ao comparar com números válidos... Os valores seraão comparados como números
- Strings que não são números. Exemplo "A", "B", "X"..., ao comparar com números válidos, Serão convertidos para zero (0)
- Valores booleanos comparados com números válidos... Os valores serão comparados como números

c) Usar o operador adequado à necessidade:
Exemplo: == (compara apenas valores); === (compara valores e tipos); != (apenas valores); !== (valores e tipos)...

*/

echo "Comparando == (apenas valores) comparação FROUXA: " . PHP_EOL;
var_dump(7 == "7");
var_dump("a" == 0);
var_dump(true == 1);

echo PHP_EOL;
echo "Comparando == (valores e tipos) comparação RÍGIDA: " . PHP_EOL;
var_dump(7 === "7");
var_dump("a" === 0);
var_dump(true === 1);

?>