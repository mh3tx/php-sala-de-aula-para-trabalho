<?php 

/*
PRECEDÊNCIA DE OPERADORES...

- Indica quem tem maior prioridade de execução na expressão.
- Parênteses podem ser usados para forçar a precedência. Ainda ajudam na legibilidade do código.
- Mas o que fazer quando a expressão tem a mesma precedência? A associatividade resolve (ver tabela no manual)
*/

$valor = (2 + 3) * 2;
echo $valor . PHP_EOL;

$valor = 3 - (1 - 2);
echo $valor . PHP_EOL;

$valor = 3 ** (2 - 2);
echo $valor . PHP_EOL;

?>