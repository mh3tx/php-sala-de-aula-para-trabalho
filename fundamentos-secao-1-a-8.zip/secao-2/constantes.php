<?php

/*
- Constantes, ao contrário de variáveis, tem seus valores imutáveis depois de declarados.
- Tipicamente utilizadas para armazenar valores que serão muito usados na aplicação.
- Seguem regras similares às variáveis em termos de nomenclatura, exceto pelo $.
- Sugere-se declarar constantes em caixa alta... por convenção...
- define() ou const: comandos usados para se declarar constantes...
- defined(o_identificar) -> verifica se a constante já foi definida...
- constant(o_identificador) -> retorna o valor da constante caso já tenha sido definida (caso ela exista).
- dentro de classes (PHP orientado a objetos) deve-se usar const pois define não funciona.
 */

//const USUARIO = "pedro.silva"; //invalido pois const só posso usar em tempo de construção do código.


if (1 == 1) {
	define("USUARIO", "maria.silva"); //valido pois posso declarar em tempo de execução (quando tá rodando).	
}




if (defined("USUARIO")) {
	echo constant("USUARIO");
}	
?>