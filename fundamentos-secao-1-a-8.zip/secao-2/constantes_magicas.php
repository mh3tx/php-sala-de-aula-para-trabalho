<?php

/*
- constantes mágicas no PHP...
Exemplos:

__CLASS__ ( nome da classe )
__METHOD__ ( nome do método de classe )
__NAMESPACE__ ( nome do atual namespace )
__LINE__ ( linha atual do script )
__FILE__ ( caminho completo e nome do arquivo )
__DIR__ ( diretório do arquivo )
__FUNCTION__ ( nome da função )

*/

echo __LINE__ . PHP_EOL;
//qualquer coisa...
//qualquer outra coisa...
echo __LINE__ . PHP_EOL;
?>