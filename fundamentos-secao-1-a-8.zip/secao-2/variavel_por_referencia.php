<?php

/*
Variáveis e referência...
*/

$x = 5;
$y = $x; //y recebe uma cópia do valor de x 
$z = &$x; //z recebe o endereço de memória de x. Logo tanto x quanto z compartilham o mesmo valor.

$z = 10; //alterar o valor de z implica em alterar tbm o valor de x, pois apontam para o mesmo endereço de memória

echo $x; //Logo, x e z armazenam o valor 10.
?>