<?php
/*
Conceitos de: sub rotina (procedimentos e funções) aliados às boas práticas 
de programação: menos é mais; padronize; favoreça a liberdade: baixo acoplamento e alta coesão.

- Programa que apresenta o resultado das 4 operações básicas entre 2 inteiros.
Versão 1: usar sub rotinas...
Versão 2: permitir passar os valores e o sinal (passar parâmetro)...
Versão 3: manter a capacidade de mostrar as 4 operações...
*/

//função
function retornaSoma(int $a, int $b): int
{
	return $a + $b;
}

//função
function retornaSubtracao(int $a, int $b): int
{
	return $a - $b;
}

//função
function retornaMultiplicacao(int $a, int $b): int
{
	return $a * $b;
}

//função
function retornaDivisao(int $a, int $b): float
{
	return $a / $b;
}

//procedimento
function mostraTitulo(int $a, int $b)
{
	echo "Os valores são: $a e $b" . PHP_EOL;
}

//procedimento
function mostra4Operacoes(String $sinal, int $a, int $b) 
{
	switch ($sinal)
	{
		case '+':
			echo 'Adição: ' . retornaSoma($a, $b) . PHP_EOL;
			break;
		case '-':	
			echo 'Subtração: ' . retornaSubtracao($a, $b) . PHP_EOL;
			break;
		case '*':
			echo 'Multiplicação: ' . retornaMultiplicacao($a, $b) . PHP_EOL;
			break;
		case '/':
			echo 'Divisão: ' . retornaDivisao($a, $b) . PHP_EOL;
			break;
	}
} //fim da subrotina

mostraTitulo(10, 5);
mostra4Operacoes('+', 10, 5);
mostra4Operacoes('-', 10, 5);
mostra4Operacoes('*', 10, 5);
mostra4Operacoes('/', 10, 5);

