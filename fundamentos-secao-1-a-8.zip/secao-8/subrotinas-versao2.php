<?php
/*
Conceitos de: sub rotina (procedimentos e funções) aliados às boas práticas 
de programação: menos é mais; padronize; favoreça a liberdade: baixo acoplamento e alta coesão.

- Programa que apresenta o resultado das 4 operações básicas entre 2 inteiros.
Versão 1: usar sub rotinas...
Versão 2: permitir passar os valores e o sinal (passar parâmetro)...
*/

//procedimento.
function mostra4Operacoes($sinal, $a, $b) 
{
	echo "Os valores são: $a e $b" . PHP_EOL;

	switch ($sinal)
	{
		case '+':
			echo 'Adição: ' . ($a + $b) . PHP_EOL;
			break;
		case '-':	
			echo 'Subtração: ' . ($a - $b) . PHP_EOL;
			break;
		case '*':
			echo 'Multiplicação: ' . ($a * $b) . PHP_EOL;
			break;
		case '/':
			echo 'Divisão: ' . ($a / $b) . PHP_EOL;
			break;
	}
} //fim da subrotina

mostra4Operacoes('/', 10, 5);

