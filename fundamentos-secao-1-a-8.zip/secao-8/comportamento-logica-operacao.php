<?php
//função
function retornaSoma(int $a, int $b): int
{
	return $a + $b;
}

//função
function retornaSubtracao(int $a, int $b): int
{
	return $a - $b;
}

//função
function retornaMultiplicacao(int $a, int $b): int
{
	return $a * $b;
}

//função
function retornaDivisao(int $a, int $b): float
{
	return $a / $b;
}

