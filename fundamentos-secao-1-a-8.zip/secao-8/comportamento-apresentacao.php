<?php
include "comportamento-logica-operacao.php";

//procedimento...
function mostraTitulo(int $a, int $b)
{
	echo "Os valores são: $a e $b" . PHP_EOL;	
}

//procedimento...
function mostraOperacao(String $sinal, int $a, int $b) 
{ 
	switch ($sinal) {
		case '+':
			echo 'Adição: ' . retornaSoma($a, $b) . PHP_EOL;
			break;
		case '-':
			echo 'Subtração: ' . retornaSubtracao($a, $b) . PHP_EOL;
			break;
		case '*':
			echo 'Multiplicação: ' . retornaMultiplicacao($a, $b) . PHP_EOL;
			break;
		case '/':
			echo 'Divisão: ' . retornaDivisao($a, $b) . PHP_EOL;
	}
} //fim da subrotina

mostraTitulo(10, 2);
mostraOperacao('+', 10, 2);
