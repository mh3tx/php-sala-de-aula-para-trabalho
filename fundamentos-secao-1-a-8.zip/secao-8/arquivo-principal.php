<?php
/*
include x include_once
require x require_once
*/

echo "eu sou o arquivo principal." . PHP_EOL;

include "../secundario/arquivo-secundario.php";

