<?php
/*
Separando em arquivos...
Entendendo: include, include_once, require, require_once
*/
echo "eu sou o arquivo secundário." . PHP_EOL;