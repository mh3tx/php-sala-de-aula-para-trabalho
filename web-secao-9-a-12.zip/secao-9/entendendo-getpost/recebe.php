<!DOCTYPE html>

<?php
/*
1 - resgatar os dados que vieram na requisição... OK
2 - apresentar na tela... OK
*/

$nome = $_REQUEST['nome'];
$idade = $_REQUEST['idade'];
?>


<html>
	<head>
		<title>Listando dados de alunos</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/estilos.css"> 
	</head>
	<body>
		<table>
			<tr>
				<th>Nome</th>
				<th>Idade</th>
			</tr>
			<tr>
				<td><?=$nome ?></td>
				<td><?=$idade ?></td>
			</tr>
		</table>
	</body>
</html>

