/*Arquivo para funções específicas de alunos*/

function validaForm() 
{
	var nome = document.getElementById('nome').value;
	var idade = document.getElementById('idade').value;
	
	document.getElementById('msg-erro').innerHTML = '';
	
	//validação parte 1: campos vazios...
	if (validaCampos(nome, idade) == false) {
		document.getElementById('msg-erro').innerHTML = 'Campos com * são obrigatórios.';
		return false;
	}
	
	//validacao parte 2: faixa de idade entre 1 e 100...
	if (validaFaixaValor(idade) == false) {
		document.getElementById('msg-erro').innerHTML = 'Idade deve estar entre 1 e 100.';
		return false;
	}	
		
	//se tudo estiver validado com sucesso...	
	document.form1.action = 'recebe.php';
	document.form1.submit();
	
}

function validaCampos(nome, idade) 
{
	var vazio = 0;

	if (nome == '') vazio++;
	if (idade == '') vazio++;
	
	if (vazio > 0) {
		return false;
	}
	
	return true;
	
}