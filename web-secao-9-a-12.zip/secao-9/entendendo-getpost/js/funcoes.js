/*Arquivo para funções genéricas para todo o sistema*/

function validaFaixaValor(valor)
{
	if (valor < 1 || valor > 100) {
		return false;
	}
	
	return true;
}



