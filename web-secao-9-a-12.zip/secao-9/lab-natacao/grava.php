<?php
$nome = $_POST['nome'];
$idade = $_POST['idade'];

if ($idade < 6 || $idade > 100) {
	header('Location: erro-idade.php');
	die();
}

$categoria = "";

if ($idade >= 6 && $idade <= 9) $categoria = "Kids";
if ($idade >= 10 && $idade <= 14) $categoria = "Infantil";
if ($idade >= 15 && $idade <= 17) $categoria = "Juvenil";
if ($idade >= 18 && $idade <= 44) $categoria = "Adulto";
if ($idade >= 45) $categoria = "Senior";


$conexao = mysqli_connect("localhost:3308", "root", "", "natacaodb");
$query = "insert into alunos (nome, idade, categoria) values ('{$nome}', {$idade}, '{$categoria}')";
$resultado = mysqli_query($conexao, $query);

header('Location: lista.php');
die();
