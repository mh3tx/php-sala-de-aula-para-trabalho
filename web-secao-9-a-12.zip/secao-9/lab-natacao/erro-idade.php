<!DOCTYPE html>
<html>
	<head>
		<title>Erro</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/estilos.css"> 
	</head>
	<body>
		<span id="erro-idade" class="fonte-erro-padrao">Idade deve estar entre 6 e 100 anos.</span>
		<br/>
		<a href="cadastro.php">Voltar para o cadastro</a> |	<a href="lista.php">Listagem</a>
	</body>
</html>