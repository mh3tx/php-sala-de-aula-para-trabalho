/*Arquivo para funções genéricas para todo o sistema*/

function validaFaixaValor(valor)
{
	if (valor < 6 || valor > 100) {
		return false;
	}
	
	return true;
}



