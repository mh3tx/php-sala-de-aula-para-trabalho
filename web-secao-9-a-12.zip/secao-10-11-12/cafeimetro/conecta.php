<?php
//$conexao = mysqli_connect('localhost:3308','root','','cafeimetrodb');
//mysqli_set_charset($conexao, 'utf8');

$conexao = new mysqli('localhost:3308','root','','cafeimetrodb');
$conexao->set_charset('utf8');






