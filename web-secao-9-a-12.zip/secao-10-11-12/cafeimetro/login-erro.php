<!DOCTYPE html>
<html>
	<head>
		<title>Cafeímetro</title>
		<meta charset="utf-8">
		<link href="css/bootstrap/bootstrap.css" rel="stylesheet" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>

	<body>
		<div class="container  text-center">
		
			<i class="fa fa-thumbs-down fa-5x"></i><br/>

			<p class="text-danger">Usuário não autorizado</p>
			
			<a href="login-form.php">Voltar para tela de login</a>
		</div>	
	</body>
</html>	