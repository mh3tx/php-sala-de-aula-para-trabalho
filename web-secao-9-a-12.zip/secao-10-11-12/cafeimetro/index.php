<?php
header("Location: login-form.php");
die();

