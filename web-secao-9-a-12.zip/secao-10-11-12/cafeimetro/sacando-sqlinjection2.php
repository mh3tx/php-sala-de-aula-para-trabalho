<?php
include 'conecta.php';
include 'cafe-banco.php';


echo "Sacando SQL Injection<br>";



$nome = $_POST['nome'];
//echo $nome;

$oCafe = buscaCafePorNome($conexao, $nome);
?>
