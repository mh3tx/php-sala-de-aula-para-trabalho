<?php
echo "Sacando SQL Injection";


?>

<!DOCTYPE html>
<html>
<head></head>
<body>

	<form name="form1" action="sacando-sqlinjection2.php" method="post">
		Informe o café: 
		<input type="text" name="nome" id="nome" value="" size="75" />
		<input type="submit" value="OK" />
	</form>
</body>
</html>