<?php

echo 'Usando MD5: ' . md5('123');
echo "<br>";
echo 'Usando ARGON2: ' . password_hash('123', PASSWORD_ARGON2I);
echo "<br>";


//1 - 202cb962ac59075b964b07152d234b70
//2 - 202cb962ac59075b964b07152d234b70
//3 - 202cb962ac59075b964b07152d234b70

//1 - $argon2i$v=19$m=65536,t=4,p=1$c3M2UEtDelNrZ1ZwZkkuVw$Ezf4MluG0A1FGSLsGbOxEkGZsywwHyp6G0cLVIPbGOY
//2 - $argon2i$v=19$m=65536,t=4,p=1$NjBZZFR2NW9EdkFwbUwzQw$0RdhYIlx8wrUmvw7CeoTj9/1lZCr9oeMLlWxy2xgbnk
//3 - $argon2i$v=19$m=65536,t=4,p=1$TGhWcnQyOTNFQ2FYZ1FRag$mfqpa4Ybc+kLYH0BpUn5XvG1MZRWkfRZoh9xf50TwEI

