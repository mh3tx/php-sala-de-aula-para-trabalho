<?php
$valor_total = 0;
$ml_total = 0;
$cafe_total = 0;
$data_hoje = date('d/m/Y H:m:s');
