<?php
include('cabecalho-menu.php');
include('rodape.php');